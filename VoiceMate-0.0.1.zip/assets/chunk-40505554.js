import{v as l,d as h}from"./chunk-9bcb95f7.js";console.log("background is running");chrome.runtime.onInstalled.addListener(()=>{chrome.contextMenus.create({id:"sendToAudio",title:"Narrate",contexts:["page"]})});chrome.contextMenus.onClicked.addListener((a,e)=>{a.menuItemId==="sendToAudio"&&e&&e.id&&chrome.storage.sync.get(["voice"],c=>{const i=c.voice||l.filter(n=>n.name===h)[0];console.log("Sending content from URL:",e.url),chrome.scripting.executeScript({target:{tabId:e.id},func:d,args:[i]}).then(n=>{const r=n[0].result;console.log("Script executed:",r),r&&chrome.tabs.create({url:r})}).catch(n=>{console.error("Error executing script:",n)})})});async function d(a){let e="";const c=document.querySelectorAll("article");if(c.length>0)c.forEach(s=>{s.querySelectorAll("p, h1, h2, h3, h4, h5, h6, li").forEach(t=>{switch(t.tagName.toUpperCase()){case"P":e+=t.innerText+`

`;break;case"H1":e+="# "+t.innerText+`

`;break;case"H2":e+="## "+t.innerText+`

`;break;case"H3":e+="### "+t.innerText+`

`;break;case"H4":e+="#### "+t.innerText+`

`;break;case"H5":case"H6":e+="##### "+t.innerText+`

`;break;case"LI":e+="- "+t.innerText+`
`;break;case"SPAN":e+=t.innerText+" "}})});else{const s=document.querySelectorAll("section");s.length>0?s.forEach(t=>{t.querySelectorAll("p, h1, h2, h3, h4, h5, h6, li").forEach(o=>{switch(o.tagName.toUpperCase()){case"P":e+=o.innerText+`

`;break;case"H1":e+="# "+o.innerText+`

`;break;case"H2":e+="## "+o.innerText+`

`;break;case"H3":e+="### "+o.innerText+`

`;break;case"H4":e+="#### "+o.innerText+`

`;break;case"H5":case"H6":e+="##### "+o.innerText+`

`;break;case"LI":e+="- "+o.innerText+`
`;break;case"SPAN":e+=o.innerText+" "}})}):e=document.body.innerText}const n=await fetch("https://us-central1-fan-id-386710.cloudfunctions.net/convertToSSML",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({text:e,voice:a})});if(console.log("response:",n.status),!n.ok)throw new Error("Network response was not ok");return(await n.json()).url}
