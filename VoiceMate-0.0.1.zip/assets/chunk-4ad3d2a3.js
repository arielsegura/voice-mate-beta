import{v as l,d}from"./chunk-9bcb95f7.js";console.log("background is running");chrome.runtime.onInstalled.addListener(()=>{chrome.action.setBadgeText({text:""}),chrome.action.setBadgeBackgroundColor({color:"#000"}),chrome.contextMenus.create({id:"sendToAudio",title:"Narrate",contexts:["page"]})});chrome.runtime.onStartup.addListener(()=>{chrome.action.setBadgeText({text:""}),chrome.action.setBadgeBackgroundColor({color:"#000"})});chrome.contextMenus.onClicked.addListener((s,e)=>{s.menuItemId==="sendToAudio"&&e&&e.id&&chrome.storage.sync.get(["voice"],c=>{const i=c.voice||l.filter(n=>n.name===d)[0];chrome.action.setBadgeText({text:"Working..."}),chrome.contextMenus.update("sendToAudio",{title:"Narrating...",enabled:!1}),chrome.scripting.executeScript({target:{tabId:e.id},func:h,args:[i]}).then(n=>{const r=n[0].result;console.log("Script executed:",r),r&&chrome.tabs.create({url:r})}).catch(n=>{console.error("Error executing script:",n)}).finally(()=>{chrome.contextMenus.update("sendToAudio",{title:"Narrate",enabled:!0}),chrome.action.setBadgeText({text:""})})})});async function h(s){let e="";const c=document.querySelectorAll("article");if(c.length>0)c.forEach(a=>{a.querySelectorAll("p, h1, h2, h3, h4, h5, h6, li").forEach(t=>{switch(t.tagName.toUpperCase()){case"P":e+=t.innerText+`

`;break;case"H1":e+="# "+t.innerText+`

`;break;case"H2":e+="## "+t.innerText+`

`;break;case"H3":e+="### "+t.innerText+`

`;break;case"H4":e+="#### "+t.innerText+`

`;break;case"H5":case"H6":e+="##### "+t.innerText+`

`;break;case"LI":e+="- "+t.innerText+`
`;break;case"SPAN":e+=t.innerText+" "}})});else{const a=document.querySelectorAll("section");a.length>0?a.forEach(t=>{t.querySelectorAll("p, h1, h2, h3, h4, h5, h6, li").forEach(o=>{switch(o.tagName.toUpperCase()){case"P":e+=o.innerText+`

`;break;case"H1":e+="# "+o.innerText+`

`;break;case"H2":e+="## "+o.innerText+`

`;break;case"H3":e+="### "+o.innerText+`

`;break;case"H4":e+="#### "+o.innerText+`

`;break;case"H5":case"H6":e+="##### "+o.innerText+`

`;break;case"LI":e+="- "+o.innerText+`
`;break;case"SPAN":e+=o.innerText+" "}})}):e=document.body.innerText}const n=await fetch("https://us-central1-fan-id-386710.cloudfunctions.net/convertToSSML",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({text:e,voice:s})});if(console.log("response:",n.status),!n.ok)throw new Error("Network response was not ok");return(await n.json()).url}
